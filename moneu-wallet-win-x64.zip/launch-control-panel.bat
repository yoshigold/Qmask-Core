@echo off
title QMASK MASTER SWARM OPERATIONAL CONTROL PANEL
cls
:loop
moneu-cli.exe 339991
echo ----------------------------------------------------------------------------------------
echo 🛰️  ALL-IN-ONE ENGINE ACTIVE: Zodiac star wheels online! QMJ and QME accumulating live!
echo 🛰️  Press [Ctrl + C] to halt control panel monitor.
timeout /t 3 >nul
goto loop
