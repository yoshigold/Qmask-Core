#!/bin/bash
stty sane && reset && clear && printf "\033[3J"
printf "\033[?25l"
./moneu-cli --game-panel ' '
echo "👑 COMPETITIVE SWARM MODE ACTIVE: Live global leaderboard online!"
echo "👉 Pilot map sectors via [W, A, S, D] keys | Press [Ctrl + C] to exit."

while true; do
    read -rsn1 key
    if [[ "$key" == $'\x1b' ]]; then read -rsn2 -t 0.05 target; continue; fi
    if [[ "$key" =~ ^[wWaAsSdD123pP\ ]$ ]]; then
        tput cup 0 0
        ./moneu-cli --game-panel "$key"
        status=$?
        if [ "$status" -eq 3 ]; then
            tput cup 26 0
            echo -e "\033[1;31m⚡⚠️  PHASE FRICTION BLOWBACK: Shoved back 1 step! ⚠️⚡\033[K"
            sleep 0.4
            clear && printf "\033[3J" && ./moneu-cli --game-panel ' '
            continue
        fi
    fi
done
