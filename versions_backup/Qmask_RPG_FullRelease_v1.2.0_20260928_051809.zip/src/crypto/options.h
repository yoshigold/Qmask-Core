/**
 * Copyright (c) 2013-2014 Pavol Rusnak
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef __OPTIONS_H__
#define __OPTIONS_H__

#ifndef OPTIMIZE_SIZE
#define OPTIMIZE_SIZE 1
#endif

#ifndef OPTIMIZE_SIZE_BLAKE2S
#define OPTIMIZE_SIZE_BLAKE2S 0
#endif

#ifndef OPTIMIZE_SIZE_BLAKE2B
#define OPTIMIZE_SIZE_BLAKE2B OPTIMIZE_SIZE
#endif

#ifndef OPTIMIZE_SIZE_ED25519
// Zero, not OPTIMIZE_SIZE.
//
// With this set, ge25519_scalarmult_base_wrapper treats the base point like
// any other point and walks the full scalar multiplication; with it clear,
// it uses the 256-entry table of base-point multiples. Both are constant
// time, so nothing is traded away but 24 kB of binary - and that buys
// roughly three times the signing rate. Every signature does this twice and
// every address once, which is why unlocking a wallet and building a
// transaction were slower than they had to be. The size setting comes from
// Trezor, where flash is the scarce thing; on a node it is not.
#define OPTIMIZE_SIZE_ED25519 0
#endif

// use precomputed Curve Points (some scalar multiples of curve base point G)
#ifndef USE_PRECOMPUTED_CP
#define USE_PRECOMPUTED_CP 0
#endif

// use fast inverse method
#ifndef USE_INVERSE_FAST
#define USE_INVERSE_FAST 1
#endif

// support for printing bignum256 structures via printf
#ifndef USE_BN_PRINT
#define USE_BN_PRINT 0
#endif

// use deterministic signatures
#ifndef USE_RFC6979
#define USE_RFC6979 1
#endif

// implement BIP32 caching
#ifndef USE_BIP32_CACHE
#define USE_BIP32_CACHE 1
#define BIP32_CACHE_SIZE 10
#define BIP32_CACHE_MAXDEPTH 8
#endif

// support constructing BIP32 nodes from ed25519 and curve25519 curves.
#ifndef USE_BIP32_25519_CURVES
#define USE_BIP32_25519_CURVES 1
#endif

// BIP39 caching. Disabled: the cache keeps the mnemonic, the passphrase and
// the derived 64-byte seed together in a static table for the life of the
// process, so the wallet's most sensitive material would survive every
// attempt to wipe it and could reach a core dump or the swap file. It exists
// to avoid repeating PBKDF2, which this node runs rarely - once per unlock -
// so the trade is not worth taking here.
#ifndef USE_BIP39_CACHE
#define USE_BIP39_CACHE 0
#define BIP39_CACHE_SIZE 4
#endif

// support Ethereum operations
#ifndef USE_ETHEREUM
#define USE_ETHEREUM 0
#endif

// support NEM operations
#ifndef USE_NEM
#define USE_NEM 0
#endif

// support MONERO operations
#ifndef USE_MONERO
#define USE_MONERO 0
#endif

// support CARDANO operations
#ifndef USE_CARDANO
#define USE_CARDANO 0
#endif

// support Keccak hashing
#ifndef USE_KECCAK
#define USE_KECCAK 1
#endif

// add way how to mark confidential data
#ifndef CONFIDENTIAL
#define CONFIDENTIAL
#endif

// add way how to mark local confidential data in functions
#ifndef LOCAL_CONFIDENTIAL
#define LOCAL_CONFIDENTIAL
#endif

// add way to mark functions whose return value should always be checked
#ifndef __wur
#define __wur __attribute__((warn_unused_result))
#endif

#endif
