#!/bin/bash
clear && printf "\033[3J"
./moneu-cli --game-panel ' '
while true; do
    read -rsn1 key
    if [[ "$key" == $'\x1b' ]]; then read -rsn2 -t 0.05 target; continue; fi
    if [[ "$key" =~ ^[wWaAsSdD123pP]$ ]]; then ./moneu-cli --game-panel "$key"; fi
done
